# plugin.video.wrp-metaplayer
WRP-MetaPlayer Kodi Add-on
