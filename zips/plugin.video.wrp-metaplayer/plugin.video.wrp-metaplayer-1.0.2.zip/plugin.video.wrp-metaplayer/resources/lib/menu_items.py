# -*- coding: utf-8 -*-

from resources.lib import lists
from resources.lib import nav_movies
from resources.lib import nav_tvshows
from resources.lib.xswift2 import plugin



@plugin.route('/')
def root():
	items = [
	{
		'label': 'Filme',
		'path': plugin.url_for('movies'),
		'thumbnail': plugin.get_media_icon('movies'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'TV Serien',
		'path': plugin.url_for('tv'),
		'thumbnail': plugin.get_media_icon('tv'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Trakt Konto',
		'path': plugin.url_for('my_trakt'),
		'thumbnail': plugin.get_media_icon('trakt'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Suche...',
		'path': plugin.url_for('search_term'),
		'thumbnail': plugin.get_media_icon('search'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Addon Einstellungen',
		'path': plugin.url_for('open_settings'),
		'thumbnail': plugin.get_media_icon('settings'),
		'fanart': plugin.get_addon_fanart()
	}]
        
        return items

@plugin.route('/movies')
def movies():
	items = [
	{
		'label': 'Blockbuster (TMDB)',
		'path': plugin.url_for('tmdb_movies_blockbusters', page=1),
		'thumbnail': plugin.get_media_icon('most_voted'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('tmdb_movies_play_random_blockbuster'))]
	},
	{
		'label': 'Im Kino (TMDB)',
		'path': plugin.url_for('tmdb_movies_now_playing', page=1),
		'thumbnail': plugin.get_media_icon('intheatres'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('tmdb_movies_play_random_now_playing'))]
	},
	{
		'label': 'Populäre Filme (TMDB)',
		'path': plugin.url_for('tmdb_movies_popular', page=1),
		'thumbnail': plugin.get_media_icon('popular'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('tmdb_movies_play_random_popular'))]
	},
	{
		'label': 'Bestbewertete Filme (TMDB)',
		'path': plugin.url_for('tmdb_movies_top_rated', page=1),
		'thumbnail': plugin.get_media_icon('top_rated'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('tmdb_movies_play_random_top_rated'))]
	},
	{
		'label': 'Meist gesehene Filme (Trakt)',
		'path': plugin.url_for('trakt_movies_watched', page=1),
		'thumbnail': plugin.get_media_icon('traktwatchlist'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('trakt_movies_play_random_watched'))]
	},
	{
		'label': 'Am meisten gesammelte Filme (Trakt)',
		'path': plugin.url_for('trakt_movies_collected', page=1),
		'thumbnail': plugin.get_media_icon('traktcollection'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('trakt_movies_play_random_collected'))]
	},
	{
		'label': 'Populäre Filme (Trakt)',
		'path': plugin.url_for('trakt_movies_popular', page=1),
		'thumbnail': plugin.get_media_icon('traktrecommendations'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('trakt_movies_play_random_popular'))]
	},
	{
		'label': 'Film Trend (Trakt)',
		'path': plugin.url_for('trakt_movies_trending', page=1),
		'thumbnail': plugin.get_media_icon('trending'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('trakt_movies_play_random_trending'))]
	},
	{
		'label': 'Neuste Veröffentlichungen (Trakt)',
		'path': plugin.url_for('trakt_movies_latest_releases'),
		'thumbnail': plugin.get_media_icon('traktcalendar'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('trakt_movies_play_random_latest_releases'))]
	},
	{
		'label': 'Top 250 Filme (IMDB)',
		'path': plugin.url_for('trakt_movies_imdb_top_rated', page=1),
		'thumbnail': plugin.get_media_icon('imdb'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('trakt_movies_play_random_imdb_top_rated'))]
	},
	{
		'label': 'Genres',
		'path': plugin.url_for('tmdb_movies_genres'),
		'thumbnail': plugin.get_media_icon('genres'),
		'fanart': plugin.get_addon_fanart()
	}]
	return items

@plugin.route('/tv')
def tv():
	items = [
	{
		'label': 'Live auf Sendung (TMDB)',
		'path': plugin.url_for('tmdb_tv_on_the_air', page=1),
		'thumbnail': plugin.get_media_icon('ontheair'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Populäre Serien (TMDB)',
		'path': plugin.url_for('tmdb_tv_most_popular', page=1),
		'thumbnail': plugin.get_media_icon('popular'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Meist gesehene Serien (Trakt)',
		'path': plugin.url_for('trakt_tv_watched', page=1),
		'thumbnail': plugin.get_media_icon('traktwatchlist'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Am meisten gesammelte Serien (Trakt)',
		'path': plugin.url_for('trakt_tv_collected', page=1),
		'thumbnail': plugin.get_media_icon('traktcollection'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Am meisten gesammelte Serien bei Netflix (Trakt)',
		'path': plugin.url_for('trakt_netflix_tv_collected', page=1),
		'thumbnail': plugin.get_media_icon('traktcollection'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Populäre Serien (Trakt)',
		'path': plugin.url_for('tv_trakt_popular', page=1),
		'thumbnail': plugin.get_media_icon('traktrecommendations'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Serien Trend (Trakt)',
		'path': plugin.url_for('trakt_tv_trending', page=1),
		'thumbnail': plugin.get_media_icon('trending'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Genres',
		'path': plugin.url_for('tmdb_tv_genres'),
		'thumbnail': plugin.get_media_icon('genres'),
		'fanart': plugin.get_addon_fanart()
	}]
	return items

@plugin.route('/my_trakt')
def my_trakt():
	items = [
	{
		'label': 'Filme',
		'path': plugin.url_for('movie_lists'),
		'thumbnail': plugin.get_media_icon('movies'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'TV Serien',
		'path': plugin.url_for('tv_lists'),
		'thumbnail': plugin.get_media_icon('tv'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Listen (Filme & TV Serien)',
		'path': plugin.url_for('lists'),
		'thumbnail': plugin.get_media_icon('traktmylists'),
		'fanart': plugin.get_addon_fanart()
	}]
	return items

@plugin.route('/my_trakt/movie_lists')
def movie_lists():
	items = [
	{
		'label': 'Sammlung',
		'path': plugin.url_for('lists_trakt_movies_collection'),
		'thumbnail': plugin.get_media_icon('traktcollection'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Play (random)', 'RunPlugin(%s)' % plugin.url_for('lists_trakt_movies_play_random_collection')),
			('Add to library', 'RunPlugin(%s)' % plugin.url_for('lists_trakt_movies_collection_to_library'))]
	},
	{
		'label': 'Empfehlungen',
		'path': plugin.url_for('trakt_movies_recommendations'),
		'thumbnail': plugin.get_media_icon('traktrecommendations'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Beobachtungsliste',
		'path': plugin.url_for('trakt_movies_watchlist'),
		'thumbnail': plugin.get_media_icon('traktwatchlist'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
				('Play (random)', 'RunPlugin(%s)' % plugin.url_for('trakt_movies_play_random_watchlist'))]
	},
	{
		'label': 'Meine Listen',
		'path': plugin.url_for('lists_trakt_my_movie_lists'),
		'thumbnail': plugin.get_media_icon('traktmylists'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Verknüpfte Listen',
		'path': plugin.url_for('lists_trakt_liked_movie_lists', page=1),
		'thumbnail': plugin.get_media_icon('traktlikedlists'),
		'fanart': plugin.get_addon_fanart()
	}]
	return items

@plugin.route('/my_trakt/tv_lists')
def tv_lists():
	items = [
	{
		'label': 'Sammlung',
		'path': plugin.url_for('lists_trakt_tv_collection'),
		'thumbnail': plugin.get_media_icon('traktcollection'),
		'fanart': plugin.get_addon_fanart(),
		'context_menu': [
			('Add to library', 'RunPlugin(%s)' % plugin.url_for('lists_trakt_tv_collection_to_library'))]
	},
	{
		'label': 'Empfehlungen',
		'path': plugin.url_for('trakt_tv_recommendations'),
		'thumbnail': plugin.get_media_icon('traktrecommendations'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Beobachtungsliste',
		'path': plugin.url_for('trakt_tv_watchlist', page = 1),
		'thumbnail': plugin.get_media_icon('traktwatchlist'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Meine Listen',
		'path': plugin.url_for('lists_trakt_my_tv_lists'),
		'thumbnail': plugin.get_media_icon('traktmylists'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Verknüpfte Listen',
		'path': plugin.url_for('lists_trakt_liked_tv_lists', page=1),
		'thumbnail': plugin.get_media_icon('traktlikedlists'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Nächste Folgen',
		'path': plugin.url_for('trakt_tv_next_episodes'),
		'thumbnail': plugin.get_media_icon('traktnextepisodes'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Kommende Folgen',
		'path': plugin.url_for('trakt_tv_upcoming_episodes'),
		'thumbnail': plugin.get_media_icon('traktcalendar'),
		'fanart': plugin.get_addon_fanart()
	}]
	return items

@plugin.route('/my_trakt/lists')
def lists():
	items = [
	{
		'label': 'Meine Listen',
		'path': plugin.url_for('lists_trakt_my_lists'),
		'thumbnail': plugin.get_media_icon('traktmylists'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Verknüpfte Listen',
		'path': plugin.url_for('lists_trakt_liked_lists', page=1),
		'thumbnail': plugin.get_media_icon('traktlikedlists'),
		'fanart': plugin.get_addon_fanart()
	}]
	return items

@plugin.route('/search')
def search_term():
	term = plugin.keyboard(heading='Suchbegriff eingeben')
	if term != None and term != '':
		return search(term)
	else:
		return

@plugin.route('/search/edit/<term>')
def search_edit(term):
	if term == ' ' or term == None or term == '':
		term = plugin.keyboard(heading='Suchbegriff eingeben')
	else:
		term = plugin.keyboard(default=term, heading='Suchbegriff eingeben')
	if term != None and term != '':
		return search(term)
	else:
		return

@plugin.route('/search/<term>', options = {'term': 'None'})
def search(term):
	items = [
	{
		'label': 'Film Suche (TMDB) ' + term,
		'path': plugin.url_for('tmdb_movies_search_term', term=term, page=1),
		'thumbnail': plugin.get_media_icon('search'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Film Suche (Trakt) ' + term, 
		'path': plugin.url_for('trakt_movies_search_term', term=term, page=1),
		'thumbnail': plugin.get_media_icon('search'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'TV Serien Suche (TVDB) ' + term,
		'path': plugin.url_for('tvdb_tv_search_term', term=term, page=1),
		'thumbnail': plugin.get_media_icon('search'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'TV Serien Suche (Trakt) ' + term,
		'path': plugin.url_for('trakt_tv_search_term', term=term, page=1),
		'thumbnail': plugin.get_media_icon('search'),
		'fanart': plugin.get_addon_fanart()
	},
	{
		'label': 'Listen Suche (Trakt) ' + term,
		'path': plugin.url_for('lists_search_for_lists_term', term=term, page=1),
		'thumbnail': plugin.get_media_icon('search'),
		'fanart': plugin.get_addon_fanart(),
	},
	{
		'label': 'Suchbegriff eingeben',
		'path': plugin.url_for('search_edit', term=term),
		'thumbnail': plugin.get_media_icon('search'),
		'fanart': plugin.get_addon_fanart()
	}]
	return items
