
# Skin Aura WRP Mod Kodi Add-on


![logo](resources/icon.png)

***

Der Skin Aura WRP Mod ist eine anpassbare Skin Oberfläche mit mehreren Widgets und einem horizontalen Startmenü. Der Aura WRP Mod kombiniert den Minimalismus und die abgerundeten Kanten von Arctic Zephyr mit der schlanken Anpassbarkeit von Horizon. Während das beste Aura WRP Mod-Erlebnis mit einer Fernbedienung erzielt wird, wurde Aura WRP Mod entwickelt, um Maus- und Touch-Benutzer nach Möglichkeit unterzubringen.

***
[![Gitter](https://badges.gitter.im/WRP-Lounge/WRP-Metaplayer.svg)](https://gitter.im/WRP-Lounge/WRP-Metaplayer?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge) Hier findet ihr Hilfe wenn es um WRP-Addons geht.

![logo](resources/screenshot-00.jpg)

***

Original Source Code Forked from Aura Skin
